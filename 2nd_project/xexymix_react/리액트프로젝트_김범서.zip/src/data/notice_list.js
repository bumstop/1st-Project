export const noticeList = [
  { txt: "미사용 적립금 자동 소멸 및 적립금 운영 정책 안내", link: "" },
  { txt: "젝시믹스 회원 등급별 혜택 안내", link: "" },
  { txt: "오프라인 매장 재고 조회 서비스 오픈", link: "" },
  { txt: "젝시믹스 포토리뷰 적립금 정책 변경안내", link: "" },
  { txt: "젝시믹스 신규회원 혜택", link: "" },
];
