export function TopBanner() {
  return (
    <div className="top-banner">
      <a href="#!">카카오톡 채널 추가 시 3천원 추가 할인!</a>
    </div>
  );
}
